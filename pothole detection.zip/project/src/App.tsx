import { useState } from 'react';
import { useAuth } from './contexts/AuthContext';
import Login from './pages/Login';
import Home from './pages/Home';
import ReportPothole from './pages/ReportPothole';
import MapView from './pages/MapView';
import NearbyAlerts from './pages/NearbyAlerts';
import CommunityReports from './pages/CommunityReports';
import About from './pages/About';

type Page = 'login' | 'home' | 'report' | 'map' | 'alerts' | 'community' | 'about';

function App() {
  const { user, loading } = useAuth();
  const [currentPage, setCurrentPage] = useState<Page>('login');

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-16 w-16 border-b-4 border-blue-900 mb-4"></div>
          <p className="text-gray-700 text-lg font-semibold">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user && currentPage !== 'login') {
    setCurrentPage('login');
  }

  const handleNavigation = (page: string) => {
    setCurrentPage(page as Page);
  };

  const handleLoginSuccess = () => {
    setCurrentPage('home');
  };

  if (!user) {
    return <Login onSuccess={handleLoginSuccess} />;
  }

  switch (currentPage) {
    case 'home':
      return <Home onNavigate={handleNavigation} />;
    case 'report':
      return <ReportPothole onNavigate={handleNavigation} />;
    case 'map':
      return <MapView onNavigate={handleNavigation} />;
    case 'alerts':
      return <NearbyAlerts onNavigate={handleNavigation} />;
    case 'community':
      return <CommunityReports onNavigate={handleNavigation} />;
    case 'about':
      return <About onNavigate={handleNavigation} />;
    default:
      return <Home onNavigate={handleNavigation} />;
  }
}

export default App;
