import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Pothole {
  id: string;
  user_id: string;
  image_url: string;
  location_lat: number;
  location_lng: number;
  description: string;
  severity: 'small' | 'medium' | 'dangerous';
  created_at: string;
  updated_at: string;
}

export interface PotholeRating {
  id: string;
  pothole_id: string;
  user_id: string;
  rating: number;
  created_at: string;
}

export interface CommunityReport {
  id: string;
  user_id: string;
  title: string;
  description: string;
  location_lat: number;
  location_lng: number;
  report_type: 'streetlight' | 'flooding' | 'accident' | 'construction' | 'other';
  created_at: string;
}

export interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  reputation_points: number;
  created_at: string;
}
