import { ArrowLeft, Shield, Target, Users, Award } from 'lucide-react';

interface AboutProps {
  onNavigate: (page: string) => void;
}

export default function About({ onNavigate }: AboutProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <header className="bg-gray-700 text-white shadow-lg">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center gap-3">
          <button onClick={() => onNavigate('home')} className="hover:bg-gray-600 p-2 rounded-lg transition">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
            About CrowdSafe Road
          </h1>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <div className="flex items-center gap-4 mb-6">
            <div className="bg-blue-900 p-4 rounded-full">
              <Shield className="w-12 h-12 text-white" />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'Poppins, sans-serif' }}>
                CrowdSafe Road Platform
              </h2>
              <p className="text-gray-600" style={{ fontFamily: 'Roboto, sans-serif' }}>
                Making roads safer, one report at a time
              </p>
            </div>
          </div>

          <div className="prose max-w-none">
            <p className="text-gray-700 text-lg leading-relaxed mb-6">
              CrowdSafe Road is a revolutionary crowd-sourced safety and pothole detection platform that empowers communities to identify, report, and track road hazards in real-time. Our mission is to create safer roads for everyone through the power of collective action.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="bg-orange-100 p-3 rounded-lg w-fit mb-4">
              <Target className="w-8 h-8 text-orange-500" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Our Mission
            </h3>
            <p className="text-gray-700">
              To leverage community engagement and modern technology to identify road hazards quickly, enabling faster response times and preventing accidents before they happen.
            </p>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="bg-blue-100 p-3 rounded-lg w-fit mb-4">
              <Users className="w-8 h-8 text-blue-500" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-3" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Community Powered
            </h3>
            <p className="text-gray-700">
              Every user contributes to a comprehensive database of road conditions, creating a network of safety that benefits entire communities and helps authorities prioritize repairs.
            </p>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Key Features
          </h2>
          <div className="space-y-4">
            <div className="flex gap-4">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-1">Real-Time Pothole Reporting</h4>
                <p className="text-gray-700">Upload photos and GPS locations of potholes instantly to alert other drivers and authorities.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-1">Community Rating System</h4>
                <p className="text-gray-700">Rate and verify pothole reports to ensure accuracy and help prioritize the most severe issues.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-1">Nearby Alerts</h4>
                <p className="text-gray-700">Receive notifications about potholes and hazards on your route to drive more safely.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-1">Interactive Map View</h4>
                <p className="text-gray-700">Visualize all reported potholes on an interactive map with severity-based color coding.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-1">Community Issue Reporting</h4>
                <p className="text-gray-700">Report other road safety concerns like broken street lights, flooding, and construction zones.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-900 to-blue-700 rounded-2xl shadow-lg p-8 text-white">
          <div className="flex items-center gap-4 mb-4">
            <Award className="w-12 h-12" />
            <h2 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Join the Movement
            </h2>
          </div>
          <p className="text-blue-100 mb-6">
            Every report you make contributes to safer roads for everyone. Together, we can create a comprehensive safety network that protects drivers, cyclists, and pedestrians alike.
          </p>
          <div className="grid grid-cols-3 gap-6 text-center">
            <div>
              <p className="text-4xl font-bold mb-2">100%</p>
              <p className="text-blue-200 text-sm">Community Driven</p>
            </div>
            <div>
              <p className="text-4xl font-bold mb-2">24/7</p>
              <p className="text-blue-200 text-sm">Real-Time Updates</p>
            </div>
            <div>
              <p className="text-4xl font-bold mb-2">Free</p>
              <p className="text-blue-200 text-sm">Always Free to Use</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
