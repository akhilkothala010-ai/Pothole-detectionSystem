import { useState, useEffect } from 'react';
import { ArrowLeft, Bell, AlertTriangle, Navigation } from 'lucide-react';
import { supabase, Pothole } from '../lib/supabase';

interface NearbyAlertsProps {
  onNavigate: (page: string) => void;
}

interface Alert {
  id: string;
  distance: number;
  pothole: Pothole;
}

export default function NearbyAlerts({ onNavigate }: NearbyAlertsProps) {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getUserLocation();
  }, []);

  useEffect(() => {
    if (userLocation) {
      fetchNearbyPotholes();
    }
  }, [userLocation]);

  const getUserLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        () => {
          setLoading(false);
        }
      );
    } else {
      setLoading(false);
    }
  };

  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
    const R = 6371;
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLng = ((lng2 - lng1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLng / 2) *
        Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c * 1000;
  };

  const fetchNearbyPotholes = async () => {
    if (!userLocation) return;

    setLoading(true);
    const { data: potholes } = await supabase
      .from('potholes')
      .select('*')
      .order('created_at', { ascending: false });

    if (potholes) {
      const nearbyAlerts: Alert[] = potholes
        .map((pothole) => ({
          id: pothole.id,
          distance: calculateDistance(
            userLocation.lat,
            userLocation.lng,
            pothole.location_lat,
            pothole.location_lng
          ),
          pothole,
        }))
        .filter((alert) => alert.distance <= 5000)
        .sort((a, b) => a.distance - b.distance);

      setAlerts(nearbyAlerts);
    }
    setLoading(false);
  };

  const getSeverityIcon = (severity: string) => {
    return <AlertTriangle className={`w-6 h-6 ${
      severity === 'dangerous' ? 'text-red-500' :
      severity === 'medium' ? 'text-orange-500' :
      'text-yellow-500'
    }`} />;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-red-100">
      <header className="bg-red-500 text-white shadow-lg">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center gap-3">
          <button onClick={() => onNavigate('home')} className="hover:bg-red-600 p-2 rounded-lg transition">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Nearby Alerts
          </h1>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <div className="flex items-center gap-4 mb-6">
            <div className="bg-red-100 p-4 rounded-full">
              <Bell className="w-8 h-8 text-red-500" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900" style={{ fontFamily: 'Poppins, sans-serif' }}>
                Active Alerts
              </h2>
              <p className="text-gray-600" style={{ fontFamily: 'Roboto, sans-serif' }}>
                {alerts.length} pothole{alerts.length !== 1 ? 's' : ''} detected within 5km
              </p>
            </div>
          </div>

          {!userLocation && !loading && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
              <p className="text-yellow-800">
                Location access is required to show nearby alerts. Please enable location services.
              </p>
            </div>
          )}

          {loading ? (
            <div className="text-center py-12">
              <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-red-500"></div>
              <p className="mt-4 text-gray-600">Detecting nearby potholes...</p>
            </div>
          ) : alerts.length === 0 ? (
            <div className="text-center py-12">
              <Bell className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600">No potholes detected nearby</p>
              <p className="text-sm text-gray-500 mt-2">You're on a safe route!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {alerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`border-2 rounded-lg p-6 ${
                    alert.pothole.severity === 'dangerous' ? 'border-red-300 bg-red-50' :
                    alert.pothole.severity === 'medium' ? 'border-orange-300 bg-orange-50' :
                    'border-yellow-300 bg-yellow-50'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      {getSeverityIcon(alert.pothole.severity)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-lg font-bold text-gray-900">
                          {alert.pothole.severity.charAt(0).toUpperCase() + alert.pothole.severity.slice(1)} Pothole
                        </h3>
                        <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                          alert.distance < 100 ? 'bg-red-500 text-white' :
                          alert.distance < 500 ? 'bg-orange-500 text-white' :
                          'bg-yellow-500 text-white'
                        }`}>
                          {alert.distance < 1000
                            ? `${Math.round(alert.distance)}m ahead`
                            : `${(alert.distance / 1000).toFixed(1)}km ahead`}
                        </span>
                      </div>
                      <p className="text-gray-700 mb-3">
                        {alert.pothole.description || 'No description available'}
                      </p>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Navigation className="w-4 h-4" />
                        <span>
                          {alert.pothole.location_lat.toFixed(4)}, {alert.pothole.location_lng.toFixed(4)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Safety Tips
          </h2>
          <ul className="space-y-3 text-gray-700">
            <li className="flex gap-3">
              <span className="text-red-500 font-bold">•</span>
              <span>Reduce speed when approaching reported potholes</span>
            </li>
            <li className="flex gap-3">
              <span className="text-red-500 font-bold">•</span>
              <span>Maintain safe distance from other vehicles</span>
            </li>
            <li className="flex gap-3">
              <span className="text-red-500 font-bold">•</span>
              <span>Report new potholes to help other drivers</span>
            </li>
            <li className="flex gap-3">
              <span className="text-red-500 font-bold">•</span>
              <span>Stay alert and drive carefully in marked areas</span>
            </li>
          </ul>
        </div>
      </main>
    </div>
  );
}
