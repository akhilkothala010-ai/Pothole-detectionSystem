import { useState, useEffect } from 'react';
import { ArrowLeft, MapPin } from 'lucide-react';
import { supabase, Pothole } from '../lib/supabase';

interface MapViewProps {
  onNavigate: (page: string) => void;
}

export default function MapView({ onNavigate }: MapViewProps) {
  const [potholes, setPotholes] = useState<Pothole[]>([]);
  const [selectedPothole, setSelectedPothole] = useState<Pothole | null>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);

  useEffect(() => {
    fetchPotholes();
    getUserLocation();
  }, []);

  const fetchPotholes = async () => {
    const { data } = await supabase
      .from('potholes')
      .select('*')
      .order('created_at', { ascending: false });

    if (data) {
      setPotholes(data);
    }
  };

  const getUserLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        }
      );
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'dangerous':
        return 'bg-red-500 border-red-600';
      case 'medium':
        return 'bg-orange-500 border-orange-600';
      case 'small':
        return 'bg-yellow-500 border-yellow-600';
      default:
        return 'bg-gray-500 border-gray-600';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100">
      <header className="bg-green-500 text-white shadow-lg">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center gap-3">
          <button onClick={() => onNavigate('home')} className="hover:bg-green-600 p-2 rounded-lg transition">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Map View
          </h1>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <div className="bg-gradient-to-br from-green-100 to-green-200 rounded-xl p-8 min-h-[400px] relative overflow-hidden">
            <div className="absolute top-4 right-4 bg-white rounded-lg shadow-lg p-4">
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-red-500 rounded-full"></div>
                  <span>Dangerous</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-orange-500 rounded-full"></div>
                  <span>Medium</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-yellow-500 rounded-full"></div>
                  <span>Small</span>
                </div>
              </div>
            </div>

            {userLocation && (
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                <div className="w-6 h-6 bg-blue-600 rounded-full border-4 border-white shadow-lg"></div>
              </div>
            )}

            <div className="grid grid-cols-4 gap-8 p-8">
              {potholes.map((pothole, index) => (
                <button
                  key={pothole.id}
                  onClick={() => setSelectedPothole(pothole)}
                  className={`w-8 h-8 ${getSeverityColor(pothole.severity)} rounded-full border-4 shadow-lg hover:scale-125 transition cursor-pointer`}
                  style={{
                    position: 'relative',
                    top: `${(index % 3) * 30}px`,
                    left: `${(index % 5) * 20}px`,
                  }}
                  title={`${pothole.severity} pothole`}
                />
              ))}
            </div>

            <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg p-4">
              <p className="text-sm font-semibold text-gray-900">Total Potholes: {potholes.length}</p>
            </div>
          </div>
        </div>

        {selectedPothole && (
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Pothole Details
            </h2>
            <div className="flex gap-6">
              <img
                src={selectedPothole.image_url}
                alt="Pothole"
                className="w-64 h-64 object-cover rounded-lg shadow"
              />
              <div className="flex-1">
                <div className="mb-4">
                  <span className={`px-4 py-2 rounded-full text-sm font-semibold ${
                    selectedPothole.severity === 'dangerous' ? 'bg-red-100 text-red-700' :
                    selectedPothole.severity === 'medium' ? 'bg-orange-100 text-orange-700' :
                    'bg-yellow-100 text-yellow-700'
                  }`}>
                    {selectedPothole.severity.charAt(0).toUpperCase() + selectedPothole.severity.slice(1)}
                  </span>
                </div>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-gray-600 font-semibold">Description</p>
                    <p className="text-gray-900">{selectedPothole.description || 'No description provided'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 font-semibold">Location</p>
                    <p className="text-gray-900 flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      {selectedPothole.location_lat.toFixed(4)}, {selectedPothole.location_lng.toFixed(4)}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 font-semibold">Reported</p>
                    <p className="text-gray-900">{new Date(selectedPothole.created_at).toLocaleDateString()}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="bg-white rounded-2xl shadow-lg p-8 mt-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
            All Potholes
          </h2>
          <div className="space-y-4">
            {potholes.map((pothole) => (
              <div
                key={pothole.id}
                className="flex items-center gap-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition cursor-pointer"
                onClick={() => setSelectedPothole(pothole)}
              >
                <div className={`w-4 h-4 ${getSeverityColor(pothole.severity)} rounded-full`}></div>
                <div className="flex-1">
                  <p className="font-semibold text-gray-900">
                    {pothole.severity.charAt(0).toUpperCase() + pothole.severity.slice(1)} Pothole
                  </p>
                  <p className="text-sm text-gray-600">
                    {pothole.location_lat.toFixed(4)}, {pothole.location_lng.toFixed(4)}
                  </p>
                </div>
                <p className="text-sm text-gray-500">
                  {new Date(pothole.created_at).toLocaleDateString()}
                </p>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
