import { useState, useEffect } from 'react';
import { ArrowLeft, Plus, MapPin } from 'lucide-react';
import { supabase, CommunityReport } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface CommunityReportsProps {
  onNavigate: (page: string) => void;
}

export default function CommunityReports({ onNavigate }: CommunityReportsProps) {
  const { user } = useAuth();
  const [reports, setReports] = useState<CommunityReport[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [reportType, setReportType] = useState<'streetlight' | 'flooding' | 'accident' | 'construction' | 'other'>('other');
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchReports();
  }, []);

  const fetchReports = async () => {
    const { data } = await supabase
      .from('community_reports')
      .select('*')
      .order('created_at', { ascending: false });

    if (data) {
      setReports(data);
    }
  };

  const detectLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        }
      );
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !location) return;

    setLoading(true);
    const { error } = await supabase.from('community_reports').insert({
      user_id: user.id,
      title,
      description,
      location_lat: location.lat,
      location_lng: location.lng,
      report_type: reportType,
    });

    if (!error) {
      setTitle('');
      setDescription('');
      setReportType('other');
      setLocation(null);
      setShowForm(false);
      fetchReports();
    }
    setLoading(false);
  };

  const getReportTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      streetlight: 'Street Light',
      flooding: 'Water Logging',
      accident: 'Accident Area',
      construction: 'Construction',
      other: 'Other',
    };
    return labels[type] || type;
  };

  const getReportTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      streetlight: 'bg-yellow-100 text-yellow-700',
      flooding: 'bg-blue-100 text-blue-700',
      accident: 'bg-red-100 text-red-700',
      construction: 'bg-orange-100 text-orange-700',
      other: 'bg-gray-100 text-gray-700',
    };
    return colors[type] || colors.other;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100">
      <header className="bg-blue-500 text-white shadow-lg">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center gap-3">
          <button onClick={() => onNavigate('home')} className="hover:bg-blue-600 p-2 rounded-lg transition">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold flex-1" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Community Reports
          </h1>
          <button
            onClick={() => setShowForm(!showForm)}
            className="bg-white text-blue-500 px-4 py-2 rounded-lg font-semibold hover:bg-blue-50 transition flex items-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Add Report
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        {showForm && (
          <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
              Report an Issue
            </h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Issue Title
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  placeholder="Brief title of the issue"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Issue Type
                </label>
                <select
                  value={reportType}
                  onChange={(e) => setReportType(e.target.value as typeof reportType)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                >
                  <option value="streetlight">Street Light Not Working</option>
                  <option value="flooding">Water Logging / Flooding</option>
                  <option value="accident">Accident Prone Area</option>
                  <option value="construction">Road Construction</option>
                  <option value="other">Other Issue</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Description
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  rows={4}
                  placeholder="Provide details about the issue..."
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Location
                </label>
                <button
                  type="button"
                  onClick={detectLocation}
                  className="flex items-center gap-3 bg-blue-500 text-white py-3 px-6 rounded-lg hover:bg-blue-600 transition w-full justify-center"
                >
                  <MapPin className="w-5 h-5" />
                  <span className="font-semibold">
                    {location ? `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}` : 'Detect Location'}
                  </span>
                </button>
              </div>

              <button
                type="submit"
                disabled={loading || !location}
                className="w-full bg-blue-500 text-white py-4 rounded-lg font-bold hover:bg-blue-600 transition disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
              >
                {loading ? 'Submitting...' : 'Submit Report'}
              </button>
            </form>
          </div>
        )}

        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Recent Reports
          </h2>
          <div className="space-y-4">
            {reports.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-600">No community reports yet</p>
                <p className="text-sm text-gray-500 mt-2">Be the first to report an issue!</p>
              </div>
            ) : (
              reports.map((report) => (
                <div key={report.id} className="border border-gray-200 rounded-lg p-6 hover:bg-gray-50 transition">
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="text-lg font-bold text-gray-900">{report.title}</h3>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getReportTypeColor(report.report_type)}`}>
                      {getReportTypeLabel(report.report_type)}
                    </span>
                  </div>
                  <p className="text-gray-700 mb-3">{report.description}</p>
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      <span>
                        {report.location_lat.toFixed(4)}, {report.location_lng.toFixed(4)}
                      </span>
                    </div>
                    <span>{new Date(report.created_at).toLocaleDateString()}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
