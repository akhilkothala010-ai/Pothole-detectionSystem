import { useState, useEffect } from 'react';
import { Camera, MapPin, ArrowLeft, Star } from 'lucide-react';
import { supabase, Pothole, PotholeRating } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface ReportPotholeProps {
  onNavigate: (page: string) => void;
}

export default function ReportPothole({ onNavigate }: ReportPotholeProps) {
  const { user } = useAuth();
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [description, setDescription] = useState('');
  const [severity, setSeverity] = useState<'small' | 'medium' | 'dangerous'>('medium');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [recentPotholes, setRecentPotholes] = useState<(Pothole & { avgRating?: number; ratingCount?: number })[]>([]);

  useEffect(() => {
    fetchRecentPotholes();
  }, []);

  const fetchRecentPotholes = async () => {
    const { data: potholes } = await supabase
      .from('potholes')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(5);

    if (potholes) {
      const potholesWithRatings = await Promise.all(
        potholes.map(async (pothole) => {
          const { data: ratings } = await supabase
            .from('pothole_ratings')
            .select('rating')
            .eq('pothole_id', pothole.id);

          if (ratings && ratings.length > 0) {
            const avgRating = ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length;
            return { ...pothole, avgRating, ratingCount: ratings.length };
          }
          return { ...pothole, avgRating: 0, ratingCount: 0 };
        })
      );
      setRecentPotholes(potholesWithRatings);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const detectLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        () => {
          setError('Unable to detect location. Please enable GPS.');
        }
      );
    } else {
      setError('Geolocation is not supported by your browser');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageFile || !location || !user) {
      setError('Please upload an image and detect location');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const fileExt = imageFile.name.split('.').pop();
      const fileName = `${Math.random()}.${fileExt}`;
      const filePath = `potholes/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('images')
        .upload(filePath, imageFile);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('images')
        .getPublicUrl(filePath);

      const { error: insertError } = await supabase.from('potholes').insert({
        user_id: user.id,
        image_url: publicUrl,
        location_lat: location.lat,
        location_lng: location.lng,
        description,
        severity,
      });

      if (insertError) throw insertError;

      setSuccess(true);
      setImageFile(null);
      setImagePreview('');
      setDescription('');
      setSeverity('medium');
      setLocation(null);
      fetchRecentPotholes();

      setTimeout(() => {
        setSuccess(false);
      }, 3000);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to submit report');
    } finally {
      setLoading(false);
    }
  };

  const handleRate = async (potholeId: string, rating: number) => {
    if (!user) return;

    const { error } = await supabase.from('pothole_ratings').upsert({
      pothole_id: potholeId,
      user_id: user.id,
      rating,
    }, {
      onConflict: 'pothole_id,user_id'
    });

    if (!error) {
      fetchRecentPotholes();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-orange-100">
      <header className="bg-orange-500 text-white shadow-lg">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center gap-3">
          <button onClick={() => onNavigate('home')} className="hover:bg-orange-600 p-2 rounded-lg transition">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Report Pothole
          </h1>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-4">
                Upload Pothole Image
              </label>
              <input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
                id="image-upload"
              />
              <label
                htmlFor="image-upload"
                className="flex items-center justify-center gap-3 bg-orange-500 text-white py-4 px-6 rounded-lg cursor-pointer hover:bg-orange-600 transition"
              >
                <Camera className="w-6 h-6" />
                <span className="font-semibold">Choose Photo</span>
              </label>
              {imagePreview && (
                <div className="mt-4">
                  <img src={imagePreview} alt="Preview" className="w-full h-64 object-cover rounded-lg shadow" />
                </div>
              )}
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-4">
                Location
              </label>
              <button
                type="button"
                onClick={detectLocation}
                className="flex items-center gap-3 bg-blue-500 text-white py-3 px-6 rounded-lg hover:bg-blue-600 transition w-full justify-center"
              >
                <MapPin className="w-5 h-5" />
                <span className="font-semibold">
                  {location ? `Detected: ${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}` : 'Detect from GPS'}
                </span>
              </button>
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-4">
                Description
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none"
                rows={4}
                placeholder="Describe the pothole condition..."
              />
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-900 mb-4">
                Severity Level
              </label>
              <div className="space-y-3">
                {[
                  { value: 'small', label: 'Small', color: 'bg-yellow-100 border-yellow-400' },
                  { value: 'medium', label: 'Medium', color: 'bg-orange-100 border-orange-400' },
                  { value: 'dangerous', label: 'Dangerous', color: 'bg-red-100 border-red-400' },
                ].map((option) => (
                  <label
                    key={option.value}
                    className={`flex items-center gap-3 p-4 border-2 rounded-lg cursor-pointer transition ${
                      severity === option.value ? option.color : 'bg-white border-gray-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="severity"
                      value={option.value}
                      checked={severity === option.value}
                      onChange={(e) => setSeverity(e.target.value as 'small' | 'medium' | 'dangerous')}
                      className="w-5 h-5"
                    />
                    <span className="font-semibold text-gray-900">{option.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {error && (
              <div className="bg-red-50 text-red-600 px-4 py-3 rounded-lg">
                {error}
              </div>
            )}

            {success && (
              <div className="bg-green-50 text-green-600 px-4 py-3 rounded-lg">
                Pothole reported successfully!
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-orange-500 text-white py-4 rounded-lg font-bold text-lg hover:bg-orange-600 transition disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
            >
              {loading ? 'Submitting...' : 'Submit Report'}
            </button>
          </form>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Recent Pothole Reports
          </h2>
          <div className="space-y-4">
            {recentPotholes.map((pothole) => (
              <div key={pothole.id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex gap-4">
                  <img
                    src={pothole.image_url}
                    alt="Pothole"
                    className="w-24 h-24 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                        pothole.severity === 'dangerous' ? 'bg-red-100 text-red-700' :
                        pothole.severity === 'medium' ? 'bg-orange-100 text-orange-700' :
                        'bg-yellow-100 text-yellow-700'
                      }`}>
                        {pothole.severity.charAt(0).toUpperCase() + pothole.severity.slice(1)}
                      </span>
                    </div>
                    <p className="text-gray-600 text-sm mb-2">{pothole.description || 'No description'}</p>
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          onClick={() => handleRate(pothole.id, star)}
                          className="hover:scale-110 transition"
                        >
                          <Star
                            className="w-5 h-5"
                            fill={star <= (pothole.avgRating || 0) ? '#FBBF24' : 'none'}
                            stroke={star <= (pothole.avgRating || 0) ? '#FBBF24' : '#D1D5DB'}
                          />
                        </button>
                      ))}
                      <span className="text-sm text-gray-600 ml-2">
                        ({pothole.ratingCount || 0} votes)
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
