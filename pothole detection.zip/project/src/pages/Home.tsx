import { Camera, Bell, Users, Map, Info, Shield } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface HomeProps {
  onNavigate: (page: string) => void;
}

export default function Home({ onNavigate }: HomeProps) {
  const { user, signOut } = useAuth();

  const navigationCards = [
    {
      title: 'Report Pothole',
      icon: Camera,
      color: 'bg-orange-500',
      hoverColor: 'hover:bg-orange-600',
      page: 'report',
    },
    {
      title: 'Nearby Alerts',
      icon: Bell,
      color: 'bg-red-500',
      hoverColor: 'hover:bg-red-600',
      page: 'alerts',
    },
    {
      title: 'Community Reports',
      icon: Users,
      color: 'bg-blue-500',
      hoverColor: 'hover:bg-blue-600',
      page: 'community',
    },
    {
      title: 'Map View',
      icon: Map,
      color: 'bg-green-500',
      hoverColor: 'hover:bg-green-600',
      page: 'map',
    },
    {
      title: 'About',
      icon: Info,
      color: 'bg-gray-500',
      hoverColor: 'hover:bg-gray-600',
      page: 'about',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100">
      <header className="bg-blue-900 text-white shadow-lg">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8" />
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
              CrowdSafe Road
            </h1>
          </div>
          <button
            onClick={() => signOut()}
            className="px-4 py-2 bg-white text-blue-900 rounded-lg font-semibold hover:bg-gray-100 transition"
          >
            Logout
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Poppins, sans-serif' }}>
            Welcome Back!
          </h2>
          <p className="text-gray-600" style={{ fontFamily: 'Roboto, sans-serif' }}>
            Help make our roads safer by reporting potholes and road hazards
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {navigationCards.map((card) => {
            const Icon = card.icon;
            return (
              <button
                key={card.page}
                onClick={() => onNavigate(card.page)}
                className={`${card.color} ${card.hoverColor} text-white rounded-2xl p-8 shadow-lg transform transition hover:scale-105 hover:shadow-xl`}
              >
                <div className="flex flex-col items-center gap-4">
                  <Icon className="w-16 h-16" strokeWidth={2} />
                  <h3 className="text-xl font-bold" style={{ fontFamily: 'Poppins, sans-serif' }}>
                    {card.title}
                  </h3>
                </div>
              </button>
            );
          })}
        </div>
      </main>
    </div>
  );
}
