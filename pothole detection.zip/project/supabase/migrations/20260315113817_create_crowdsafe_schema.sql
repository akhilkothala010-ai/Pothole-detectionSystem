/*
  # CrowdSafe Road Platform Database Schema
  
  ## Overview
  This migration creates the complete database structure for a crowd-sourced pothole and road safety detection platform.
  
  ## New Tables
  
  ### 1. `potholes`
  Stores pothole reports submitted by users.
  - `id` (uuid, primary key) - Unique identifier for each pothole report
  - `user_id` (uuid, foreign key) - References auth.users, the user who reported
  - `image_url` (text) - URL to the uploaded pothole image
  - `location_lat` (numeric) - Latitude coordinate of the pothole
  - `location_lng` (numeric) - Longitude coordinate of the pothole
  - `description` (text) - User-provided description of the pothole
  - `severity` (text) - Severity level: 'small', 'medium', or 'dangerous'
  - `created_at` (timestamptz) - Timestamp when report was created
  - `updated_at` (timestamptz) - Timestamp of last update
  
  ### 2. `pothole_ratings`
  Stores user ratings for pothole reports.
  - `id` (uuid, primary key) - Unique identifier for each rating
  - `pothole_id` (uuid, foreign key) - References potholes table
  - `user_id` (uuid, foreign key) - References auth.users, the user who rated
  - `rating` (integer) - Rating value (1-5 stars)
  - `created_at` (timestamptz) - Timestamp when rating was created
  - Unique constraint on (pothole_id, user_id) - Users can only rate once per pothole
  
  ### 3. `community_reports`
  Stores general community issue reports (street lights, flooding, etc.).
  - `id` (uuid, primary key) - Unique identifier for each report
  - `user_id` (uuid, foreign key) - References auth.users, the reporting user
  - `title` (text) - Brief title of the issue
  - `description` (text) - Detailed description of the issue
  - `location_lat` (numeric) - Latitude coordinate of the issue
  - `location_lng` (numeric) - Longitude coordinate of the issue
  - `report_type` (text) - Type of issue: 'streetlight', 'flooding', 'accident', 'construction', 'other'
  - `created_at` (timestamptz) - Timestamp when report was created
  
  ### 4. `user_profiles`
  Extended user profile information.
  - `id` (uuid, primary key) - References auth.users
  - `email` (text) - User's email address
  - `full_name` (text) - User's full name
  - `reputation_points` (integer) - Points earned for reporting and community contributions
  - `created_at` (timestamptz) - Account creation timestamp
  
  ## Security
  
  All tables have Row Level Security (RLS) enabled with the following policies:
  
  ### Potholes Table:
  - SELECT: Anyone (including anonymous users) can view all pothole reports
  - INSERT: Only authenticated users can create new pothole reports
  - UPDATE: Users can only update their own pothole reports
  - DELETE: Users can only delete their own pothole reports
  
  ### Pothole Ratings Table:
  - SELECT: Anyone can view ratings to see community feedback
  - INSERT: Authenticated users can add ratings (one per pothole)
  - UPDATE: Users can update their own ratings
  - DELETE: Users can delete their own ratings
  
  ### Community Reports Table:
  - SELECT: Anyone can view community reports
  - INSERT: Authenticated users can create reports
  - UPDATE: Users can update their own reports
  - DELETE: Users can delete their own reports
  
  ### User Profiles Table:
  - SELECT: Anyone can view basic user profiles (for leaderboards, attribution)
  - INSERT: Users can create their own profile on signup
  - UPDATE: Users can update their own profile
  - DELETE: Users can delete their own profile
  
  ## Important Notes
  
  1. All tables use UUID primary keys for security and scalability
  2. Foreign key constraints ensure data integrity
  3. Timestamps are stored in UTC timezone
  4. RLS policies enforce data access controls at the database level
  5. Severity levels are stored as text for flexibility but should be validated in application
  6. Image URLs will point to Supabase Storage or external image hosting
*/

-- Create potholes table
CREATE TABLE IF NOT EXISTS potholes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  image_url text NOT NULL,
  location_lat numeric NOT NULL,
  location_lng numeric NOT NULL,
  description text DEFAULT '',
  severity text NOT NULL CHECK (severity IN ('small', 'medium', 'dangerous')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create pothole_ratings table
CREATE TABLE IF NOT EXISTS pothole_ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pothole_id uuid REFERENCES potholes(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  created_at timestamptz DEFAULT now(),
  UNIQUE(pothole_id, user_id)
);

-- Create community_reports table
CREATE TABLE IF NOT EXISTS community_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text DEFAULT '',
  location_lat numeric NOT NULL,
  location_lng numeric NOT NULL,
  report_type text NOT NULL CHECK (report_type IN ('streetlight', 'flooding', 'accident', 'construction', 'other')),
  created_at timestamptz DEFAULT now()
);

-- Create user_profiles table
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text DEFAULT '',
  reputation_points integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE potholes ENABLE ROW LEVEL SECURITY;
ALTER TABLE pothole_ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE community_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- RLS Policies for potholes table
CREATE POLICY "Anyone can view potholes"
  ON potholes FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create potholes"
  ON potholes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own potholes"
  ON potholes FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own potholes"
  ON potholes FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for pothole_ratings table
CREATE POLICY "Anyone can view ratings"
  ON pothole_ratings FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create ratings"
  ON pothole_ratings FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own ratings"
  ON pothole_ratings FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own ratings"
  ON pothole_ratings FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for community_reports table
CREATE POLICY "Anyone can view community reports"
  ON community_reports FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create community reports"
  ON community_reports FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own community reports"
  ON community_reports FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own community reports"
  ON community_reports FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for user_profiles table
CREATE POLICY "Anyone can view user profiles"
  ON user_profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can create own profile"
  ON user_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON user_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can delete own profile"
  ON user_profiles FOR DELETE
  TO authenticated
  USING (auth.uid() = id);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_potholes_user_id ON potholes(user_id);
CREATE INDEX IF NOT EXISTS idx_potholes_created_at ON potholes(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_potholes_severity ON potholes(severity);
CREATE INDEX IF NOT EXISTS idx_pothole_ratings_pothole_id ON pothole_ratings(pothole_id);
CREATE INDEX IF NOT EXISTS idx_community_reports_user_id ON community_reports(user_id);
CREATE INDEX IF NOT EXISTS idx_community_reports_created_at ON community_reports(created_at DESC);